﻿Imports MySql.Data.MySqlClient

Public Class WebForm5
    Inherits System.Web.UI.Page

    Dim conn As MySqlConnection
    Dim command As MySqlCommand
    Dim reader As MySqlDataReader
    Dim insertstring As String
    Dim comman As MySqlCommand


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click
        Response.Redirect("FrontPage.aspx")
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim c As Integer
        c = 0

        If TextBox1.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox2.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox3.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox4.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox5.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox6.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox7.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox8.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox9.Text = " " Then
            MsgBox("pls enter the option")
        End If
        If TextBox10.Text = " " Then
            MsgBox("pls enter the option")
        End If
        'MsgBox("PRESS RESULTS BUTTON FOR VIEWING RESULTS")
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=mysql"

        Try
            conn.Open()
            MsgBox("connected")
            insertstring = " INSERT INTO `answers`(`q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `q7`, `q8`, `q9`, `q10`) VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" & TextBox10.Text & "')"
            command = New MySqlCommand(insertstring, conn)
            reader = command.ExecuteReader
            Dim comman As New MySqlCommand("select *from data where username= username", conn)
            conn.Close()
        Catch ex As MySqlException

        Finally
            conn.Dispose()

        End Try
        If TextBox1.Text = "a" Then
            c = c + 1
        End If
        If TextBox2.Text = "c " Then
            c = c + 1
        End If
        If TextBox3.Text = " c" Then
            c = c + 1
        End If
        If TextBox4.Text = "a " Then
            c = c + 1
        End If
        If TextBox5.Text = "a " Then
            c = c + 1
        End If
        If TextBox6.Text = " d " Then
            c = c + 1
        End If
        If TextBox7.Text = " c " Then
            c = c + 1
        End If
        If TextBox8.Text = " d " Then
            c = c + 1
        End If
        If TextBox9.Text = " a " Then
            c = c + 1
        End If
        If TextBox10.Text = "b" Then
            c = c + 1
        End If
        Session("Score") = c
        Response.Redirect("ResultPage.aspx")


    End Sub
End Class