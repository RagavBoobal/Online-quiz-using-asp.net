﻿Public Class WebForm2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click
        MsgBox("PLEASE LOGIN OR SIGNUP FOR APPLYING")
    End Sub

    Protected Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        Response.Redirect("FrontPage.aspx")
    End Sub

    Protected Sub Btn3_Click(sender As Object, e As EventArgs) Handles Btn3.Click
        MsgBox("PLEASE LOGIN OR SIGNUP FOR APPLYING")
    End Sub
End Class