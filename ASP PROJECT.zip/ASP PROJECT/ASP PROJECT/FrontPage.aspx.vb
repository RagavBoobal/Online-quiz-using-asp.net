﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        Response.Redirect("JobVaccancies.aspx")
    End Sub

    Protected Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click
        Response.Redirect("NewCandidateSignUp.aspx")
    End Sub

    Protected Sub Btn3_Click(sender As Object, e As EventArgs) Handles Btn3.Click
        Response.Redirect("ExsistingUserLogin.aspx")
    End Sub

   
End Class