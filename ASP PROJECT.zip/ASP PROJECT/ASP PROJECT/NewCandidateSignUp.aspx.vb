﻿Imports MySql.Data.MySqlClient

Public Class WebForm3
    Inherits System.Web.UI.Page

    Dim conn As MySqlConnection
    Dim command As MySqlCommand
    Dim reader As MySqlDataReader
    Dim insertstring As String
    Dim comman As MySqlCommand

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        Response.Redirect("FrontPage.aspx")
    End Sub

    Protected Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click

        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=recruiter"

        Try
            conn.Open()
            MsgBox("connected")
            insertstring = " INSERT INTO `details`(`applicantname`, `emalid`, `degree`, `feild`, `applyingpost`, `workexperience`) VALUES('" & Txt1.Text & "','" & Txt2.Text & "','" & Convert.ToString(DropDownList2.SelectedItem.Text) & "','" & Convert.ToString(DropDownList3.SelectedItem.Text) & "','" & Convert.ToString(DropDownList1.SelectedItem.Text) & "','" & Txt5.Text & "')"
            command = New MySqlCommand(insertstring, conn)
            reader = command.ExecuteReader
            Dim comman As New MySqlCommand("select *from data where username= username", conn)
            Response.Redirect("ExsistingUserLogin.aspx")
            conn.Close()
        Catch ex As MySqlException

        Finally
            conn.Dispose()

        End Try

    End Sub
End Class