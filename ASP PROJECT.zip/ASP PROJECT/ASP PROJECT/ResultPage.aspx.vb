﻿Imports MySql.Data.MySqlClient
Imports System.Data

Public Class WebForm6
    Inherits System.Web.UI.Page

    Dim conn As New MySqlConnection
    Dim command As MySqlCommand
    Dim reader As MySqlDataReader
    Dim insertstring As String
    Dim comman As MySqlCommand

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            BindGridviewData()
        End If
        TextBox1.Text = Session("Score")
        If TextBox1.Text > 7 Then
            MsgBox("YOU ARE SELECTED")
        End If
    End Sub
    Public Sub BindGridviewData()
        Using con As New MySqlConnection("server=localhost;userid=root;password=;database=recruiter;")
            Using cmd As New MySqlCommand("SELECT `applicantname`, `emalid`, `degree`, `feild`, `applyingpost`, `workexperience` FROM `details`", con)
                con.Open()
                Dim ds As New DataSet()
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(ds)
                    GridView1.DataSource = ds
                    GridView1.DataBind()
                End Using
            End Using
        End Using

       
    End Sub

    Protected Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        Response.Redirect("FrontPage.aspx")
    End Sub

  
End Class