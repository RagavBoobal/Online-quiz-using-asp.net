﻿Imports MySql.Data.MySqlClient


Public Class WebForm4
    Inherits System.Web.UI.Page

    Dim conn As MySqlConnection
    Dim command As MySqlCommand
    Dim reader As MySqlDataReader
    Dim insertstring As String



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        Response.Redirect("FrontPage.aspx")
    End Sub

    Protected Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click
        Dim conn As New MySqlConnection
        Dim reader As MySqlDataReader
        conn.ConnectionString = "server=localhost;userid=root;password=;database=recruiter"
        Try
            conn.Open()
            Dim query As String
            query = "SELECT * FROM recruiter.details where applicantname='" & TextBox1.Text & "' and emalid='" & TextBox2.Text & "'"
            command = New MySqlCommand(query, conn)
            reader = command.ExecuteReader
            Dim count As Integer
            count = 0
            While reader.Read
                count = count + 1
            End While
            If count = 1 Then
                Response.Redirect("TestPage.aspx")
            ElseIf count > 1 Then
                MsgBox("username and password are incorrect")
            Else
                MsgBox("username and password are incorrect")
            End If

        Catch ex As MySqlException

        Finally

        End Try

    End Sub
End Class